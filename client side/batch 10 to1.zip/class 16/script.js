// let postive= -2;

// if(postive < 0 ){

//  postive = (postive * (-1))
 
// }

// console.log(postive)

// if (postive % 3 == 0) {

// console.log("Mulitple of 3") 

// }
// else{
//  console.log("nOT a Mulitple of 3") 
// }




// let EvenOdd=11;

// if((EvenOdd % 2 == 0) && EvenOdd !== 0 ){
// console.log("EVEN")
// }
// else if (EvenOdd == 0){
//  console.log("Neutral number")
// }
// else{
//  console.log("ODD")
// }






// let check=0;

// if (check > 0) {
//  console.log("Positive number")
// } else if(check == 0) {
//  console.log("Neutral Number")
// }
// else{
//  console.log("Negative number")
// }


// let a ,b;

// a=50;
// b=25;
// let result= (a+b);

// if ((a== 50) || (b== 50)  ) {
//  console.log(true + " some of each value is 50 ")
  
// if( ( (LEapYear % 400 == 0 ) || (LEapYear % 4 == 0) ) && (LEapYear % 100 !== 0)){

// }else{
// }

  
// }
// else if(result == 50){
// console.log(true + " from sum")
// }
// else{
//  console.log(false)
// }












// let age =11;

// condition statements

// if-else-if

// if ((age >= 18) && (age <= 25) ) {
//  console.log("legal person to apply FOR ID card")
// }
// else if (age >= 25){
//  console.log("Kindly renewed your Id Card")
// }
// else if( age >= 12){
//  console.log("not a legal person to apply FOR ID card")
// }
// else{
//  console.log("Your are a kid")
// }



// if-else

// if (age >=18) {
//  console.log("legal person to apply FOR ID card")
// }
// else{
//  console.log("not a legal person to apply FOR ID card")
// }


// if statement
// if(age !== 18){
// console.log(" legal person for NIC Card")
// }


// console.log( !(age<=18) )

      //          F               T 
// console.log(  ( age == 18 ) && (age == 18) );

// console.log(age <= 18);

