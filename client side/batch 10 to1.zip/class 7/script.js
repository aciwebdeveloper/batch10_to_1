

let num = 42;

if (num < 0) {
    console.log("The number is negative.");
}
 else if (num === 0) {
    console.log("The number is zero.");
}
 else {
    console.log("The number is positive.");
}

let f =8;

if( f % 2===0 )
{
console.log("this is even number");
}
else{
 console.log("this odd number");
}






let number1 = 50;
let number2 = 0 ;




if (number1 === 50 || number2 === 50 || number1 + number2 === 50) {
    document.write("True");
} 
else {
 document.write("False");
}



let x=5;

if(x > 0){
 document.write("positive");
}

else{
 document.write("Negative");
}
document.write("<br>");

